#include <iostream>

using namespace std;
class Fraction {
    private:
        int numerator;
        int denominator;
    public:
        Fraction() : numerator(0), denominator(1) {}
        Fraction(int _numerator, int _denominator) : numerator(_numerator),
         denominator(_denominator) {}
        Fraction operator+(const Fraction& other) const {
            return Fraction(numerator * other.denominator + other.numerator * denominator,
                 denominator * other.denominator);
        }
        Fraction operator-(const Fraction& other) const {
            return Fraction(numerator * other.denominator - other.numerator * denominator, denominator * other.denominator);
        }
        Fraction operator*(const Fraction& other) const {
            return Fraction(numerator * other.numerator, denominator * other.denominator);
        }
        Fraction operator/(const Fraction& other) const {
            return Fraction(numerator * other.denominator, denominator * other.numerator);
        }
        Fraction operator>(const Fraction& other) const {
            return Fraction(numerator * other.denominator > other.numerator * denominator, denominator * other.denominator);
        }
        Fraction operator<(const Fraction& other) const {
            return Fraction(numerator * other.denominator < other.numerator * denominator, denominator * other.denominator);
        }
        Fraction operator==(const Fraction& other) const {
            return Fraction(numerator * other.denominator == other.numerator * denominator, denominator * other.denominator);
        }
        Fraction operator!=(const Fraction& other) const {
            return Fraction(numerator * other.denominator != other.numerator * denominator, denominator * other.denominator);
        }
        Fraction operator>=(const Fraction& other) const {
            return Fraction(numerator * other.denominator >= other.numerator * denominator, denominator * other.denominator);
        }
        Fraction operator<=(const Fraction& other) const {
            return Fraction(numerator * other.denominator <= other.numerator * denominator, denominator * other.denominator);
        }
        
        void display() {
            cout << numerator << "/" << denominator << endl;
        }
        friend istream& operator>>(istream& is, Fraction& fraction) {
            is >> fraction.numerator >> fraction.denominator;
            return is;
        }
        friend ostream& operator<<(ostream& os, const Fraction& fraction) {
            os << fraction.numerator << "/" << fraction.denominator;
            return os;
        }
    };
int main() {
        Fraction a(1, 2);
        Fraction b(3, 4);
        Fraction c = a + b;
        Fraction d = a - b;
        Fraction e = a * b;
        Fraction f = a / b;
        c.display();
        d.display();
        e.display();
        f.display();
        Fraction g;
        cout << "Enter a fraction: ";
        cin >> g;
        cout << "Fraction: " << g << endl;
        return 0;
}